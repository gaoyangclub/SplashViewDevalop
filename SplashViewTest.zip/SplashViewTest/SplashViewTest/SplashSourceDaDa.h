//
//  SplashSourceDaDa.h
//  SplashViewTest
//
//  Created by admin on 16/9/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "SplashSourceView.h"

@interface SplashSourceDaDa : SplashSourceView

@property(nonatomic,retain) UIImageView* logoImg;
@property(retain, nonatomic) UILabel *nameLab;// 达达
@property(retain, nonatomic) UILabel *desLab;

@end
