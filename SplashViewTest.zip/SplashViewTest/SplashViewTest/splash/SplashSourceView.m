
//
//  SplashSourceView.m
//  SplashViewTest
//
//  Created by admin on 16/9/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "SplashSourceView.h"

@implementation SplashSourceView


-(void)display{
    
}

@end
