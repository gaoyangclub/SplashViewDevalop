//
//  LaceLayer.h
//  SplashViewTest
//
//  Created by 高扬 on 16/10/1.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface LaceLayer : CAShapeLayer

@end
