//
//  SplashSourceTransport.h
//  SplashViewTest
//
//  Created by admin on 16/9/28.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "SplashSourceView.h"

@interface SplashSourceTransport : SplashSourceView

@end
